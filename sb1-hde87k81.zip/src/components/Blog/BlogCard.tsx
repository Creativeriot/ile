import React from 'react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { BlogPost } from './types';

interface BlogCardProps {
  post: BlogPost;
  index: number;
}

export default function BlogCard({ post, index }: BlogCardProps) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true }}
      className="group overflow-hidden rounded-xl bg-white shadow-sm transition-shadow hover:shadow-md"
    >
      <div className="aspect-w-16 aspect-h-9 overflow-hidden">
        <motion.img
          whileHover={{ scale: 1.05 }}
          transition={{ duration: 0.3 }}
          src={post.image}
          alt={post.title}
          className="h-full w-full object-cover"
        />
      </div>
      <div className="p-6">
        <div className="flex items-center text-sm text-gray-500">
          <span>{format(new Date(post.date), 'MMM dd, yyyy')}</span>
          <span className="mx-2">•</span>
          <span>{post.category}</span>
        </div>
        <h3 className="mt-2 text-xl font-semibold text-gray-900 group-hover:text-green-700">
          {post.title}
        </h3>
        <p className="mt-2 line-clamp-2 text-gray-600">{post.excerpt}</p>
        <div className="mt-4">
          <a
            href={`#blog/${post.slug}`}
            className="text-sm font-medium text-green-700 hover:text-green-800"
          >
            Read more →
          </a>
        </div>
      </div>
    </motion.article>
  );
}