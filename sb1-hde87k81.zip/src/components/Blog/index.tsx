import React from 'react';
import BlogCard from './BlogCard';
import { blogPosts } from './data';

export default function Blog() {
  return (
    <section id="blog" className="bg-gray-50 py-24">
      <div className="mx-auto max-w-7xl px-4">
        <div className="text-center">
          <h2 className="text-4xl font-bold text-gray-900">Latest News</h2>
          <p className="mt-4 text-xl text-gray-600">Stay updated with golf tips and club events</p>
        </div>

        <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {blogPosts.map((post, index) => (
            <BlogCard key={post.id} post={post} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}