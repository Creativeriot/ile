export const blogPosts = [
  {
    id: 1,
    title: 'Mastering Your Golf Swing: Pro Tips',
    slug: 'mastering-golf-swing',
    excerpt: 'Learn essential techniques to improve your golf swing from our PGA professionals.',
    content: '...',
    image: 'https://images.unsplash.com/photo-1535131749006-b7f58c99034b',
    category: 'Tips & Techniques',
    date: '2024-03-15',
    author: {
      name: 'John Smith',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e'
    }
  },
  {
    id: 2,
    title: 'Upcoming Tournament Season Highlights',
    slug: 'tournament-season-highlights',
    excerpt: 'Get ready for an exciting season of tournaments at Elite Golf Club.',
    content: '...',
    image: 'https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa',
    category: 'Events',
    date: '2024-03-10',
    author: {
      name: 'Sarah Johnson',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80'
    }
  }
];