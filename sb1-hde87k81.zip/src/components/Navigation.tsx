import React from 'react';
import { Menu, User, Golf, Calendar, Phone } from 'lucide-react';

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  return (
    <nav className="fixed left-0 right-0 top-0 z-50 bg-white/95 backdrop-blur-sm">
      <div className="mx-auto max-w-7xl px-4">
        <div className="flex h-20 items-center justify-between">
          <div className="flex items-center">
            <Golf className="h-8 w-8 text-green-700" />
            <span className="ml-2 text-xl font-bold">Elite Golf Club</span>
          </div>

          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              <a href="#" className="text-gray-800 hover:text-green-700">Home</a>
              <a href="#" className="text-gray-800 hover:text-green-700">Facilities</a>
              <a href="#" className="text-gray-800 hover:text-green-700">Membership</a>
              <a href="#" className="text-gray-800 hover:text-green-700">Events</a>
              <a href="#" className="text-gray-800 hover:text-green-700">Contact</a>
            </div>
          </div>

          <div className="hidden md:block">
            <div className="ml-4 flex items-center space-x-4">
              <button className="rounded-full bg-green-700 px-4 py-2 text-white transition hover:bg-green-800">
                Book Now
              </button>
              <button className="flex items-center rounded-full border border-green-700 px-4 py-2 text-green-700 transition hover:bg-green-50">
                <User className="mr-2 h-4 w-4" />
                Member Login
              </button>
            </div>
          </div>

          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-800"
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>

      {isMenuOpen && (
        <div className="md:hidden">
          <div className="space-y-1 px-2 pb-3 pt-2">
            <a href="#" className="block rounded-md px-3 py-2 text-base font-medium text-gray-800 hover:bg-green-50">Home</a>
            <a href="#" className="block rounded-md px-3 py-2 text-base font-medium text-gray-800 hover:bg-green-50">Facilities</a>
            <a href="#" className="block rounded-md px-3 py-2 text-base font-medium text-gray-800 hover:bg-green-50">Membership</a>
            <a href="#" className="block rounded-md px-3 py-2 text-base font-medium text-gray-800 hover:bg-green-50">Events</a>
            <a href="#" className="block rounded-md px-3 py-2 text-base font-medium text-gray-800 hover:bg-green-50">Contact</a>
          </div>
        </div>
      )}
    </nav>
  );
}