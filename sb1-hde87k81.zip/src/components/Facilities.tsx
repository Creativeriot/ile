import React from 'react';
import { motion } from 'framer-motion';
import {
  Golf,
  Hotel,
  Utensils,
  Users,
  Trophy,
  Dumbbell,
  Pool,
  Coffee
} from 'lucide-react';

const facilities = [
  {
    icon: Golf,
    title: 'Championship Course',
    description: '18-hole professional golf course designed by renowned architects'
  },
  {
    icon: Hotel,
    title: 'Luxury Clubhouse',
    description: 'Modern amenities with panoramic course views'
  },
  {
    icon: Utensils,
    title: 'Fine Dining',
    description: 'Gourmet restaurant and exclusive member lounge'
  },
  {
    icon: Users,
    title: 'Pro Training',
    description: 'Expert instruction from PGA professionals'
  },
  {
    icon: Trophy,
    title: 'Tournaments',
    description: 'Regular member tournaments and events'
  },
  {
    icon: Dumbbell,
    title: 'Fitness Center',
    description: 'State-of-the-art gym and wellness facilities'
  },
  {
    icon: Pool,
    title: 'Swimming Pool',
    description: 'Olympic-sized pool with dedicated lanes'
  },
  {
    icon: Coffee,
    title: 'Members Lounge',
    description: 'Exclusive space for relaxation and networking'
  }
];

export default function Facilities() {
  return (
    <section className="bg-gray-50 py-24">
      <div className="mx-auto max-w-7xl px-4">
        <div className="text-center">
          <h2 className="text-4xl font-bold text-gray-900">World-Class Facilities</h2>
          <p className="mt-4 text-xl text-gray-600">Experience luxury and excellence in every detail</p>
        </div>

        <div className="mt-20 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {facilities.map((facility, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="group rounded-xl bg-white p-8 shadow-sm transition-all hover:shadow-md"
            >
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-green-100 text-green-700 transition-all group-hover:bg-green-700 group-hover:text-white">
                <facility.icon className="h-6 w-6" />
              </div>
              <h3 className="mb-2 text-xl font-semibold text-gray-900">{facility.title}</h3>
              <p className="text-gray-600">{facility.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}