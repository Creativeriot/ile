import React from 'react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { Calendar } from 'lucide-react';
import { Event } from './types';

interface EventCardProps {
  event: Event;
  index: number;
}

export default function EventCard({ event, index }: EventCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true }}
      className="group flex overflow-hidden rounded-lg bg-white shadow-sm transition-shadow hover:shadow-md"
    >
      <div className="w-24 flex-shrink-0 bg-green-700 p-4 text-center text-white">
        <span className="block text-2xl font-bold">
          {format(new Date(event.date), 'd')}
        </span>
        <span className="text-sm uppercase">
          {format(new Date(event.date), 'MMM')}
        </span>
      </div>
      <div className="flex-grow p-6">
        <h3 className="text-xl font-semibold text-gray-900">{event.title}</h3>
        <p className="mt-2 text-gray-600">{event.description}</p>
        <div className="mt-4 flex items-center text-sm text-gray-500">
          <Calendar className="mr-2 h-4 w-4" />
          <span>{format(new Date(event.date), 'EEEE, MMMM d, yyyy')}</span>
        </div>
      </div>
    </motion.div>
  );
}