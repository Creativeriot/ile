import React from 'react';
import EventCard from './EventCard';
import { events } from './data';

export default function Events() {
  return (
    <section id="events" className="bg-white py-24">
      <div className="mx-auto max-w-7xl px-4">
        <div className="text-center">
          <h2 className="text-4xl font-bold text-gray-900">Upcoming Events</h2>
          <p className="mt-4 text-xl text-gray-600">Join us for exciting tournaments and activities</p>
        </div>

        <div className="mt-16 space-y-6">
          {events.map((event, index) => (
            <EventCard key={event.id} event={event} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}