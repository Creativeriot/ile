export const events = [
  {
    id: 1,
    title: 'Spring Championship Tournament',
    description: 'Annual spring tournament featuring top players from the region.',
    date: '2024-04-15',
    category: 'Tournament',
    location: 'Main Course'
  },
  {
    id: 2,
    title: 'Golf Clinic: Perfecting Your Putt',
    description: 'Learn essential putting techniques from our PGA professionals.',
    date: '2024-04-20',
    category: 'Training',
    location: 'Practice Green'
  },
  {
    id: 3,
    title: 'Members Social Night',
    description: 'Evening of networking and entertainment for club members.',
    date: '2024-04-25',
    category: 'Social',
    location: 'Clubhouse'
  }
];