import React from 'react';

interface NavLinkProps {
  href: string;
  children: React.ReactNode;
  isMobile?: boolean;
}

export default function NavLink({ href, children, isMobile = false }: NavLinkProps) {
  const baseClasses = "text-gray-800 hover:text-green-700";
  const mobileClasses = "block rounded-md px-3 py-2 text-base font-medium hover:bg-green-50";
  const desktopClasses = "";

  return (
    <a
      href={href}
      className={`${baseClasses} ${isMobile ? mobileClasses : desktopClasses}`}
    >
      {children}
    </a>
  );
}