export const navigationLinks = [
  { href: '#', label: 'Home' },
  { href: '#facilities', label: 'Facilities' },
  { href: '#membership', label: 'Membership' },
  { href: '#events', label: 'Events' },
  { href: '#contact', label: 'Contact' },
];