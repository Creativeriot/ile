import React from 'react';
import NavLink from './NavLink';
import { navigationLinks } from './data';

interface MobileMenuProps {
  isOpen: boolean;
}

export default function MobileMenu({ isOpen }: MobileMenuProps) {
  if (!isOpen) return null;

  return (
    <div className="md:hidden">
      <div className="space-y-1 px-2 pb-3 pt-2">
        {navigationLinks.map((link) => (
          <NavLink key={link.href} href={link.href} isMobile>
            {link.label}
          </NavLink>
        ))}
      </div>
    </div>
  );
}