import {
  Golf,
  Hotel,
  Utensils,
  Users,
  Trophy,
  Dumbbell,
  Pool,
  Coffee
} from 'lucide-react';

export const facilities = [
  {
    icon: Golf,
    title: 'Championship Course',
    description: '18-hole professional golf course designed by renowned architects'
  },
  {
    icon: Hotel,
    title: 'Luxury Clubhouse',
    description: 'Modern amenities with panoramic course views'
  },
  {
    icon: Utensils,
    title: 'Fine Dining',
    description: 'Gourmet restaurant and exclusive member lounge'
  },
  {
    icon: Users,
    title: 'Pro Training',
    description: 'Expert instruction from PGA professionals'
  },
  {
    icon: Trophy,
    title: 'Tournaments',
    description: 'Regular member tournaments and events'
  },
  {
    icon: Dumbbell,
    title: 'Fitness Center',
    description: 'State-of-the-art gym and wellness facilities'
  },
  {
    icon: Pool,
    title: 'Swimming Pool',
    description: 'Olympic-sized pool with dedicated lanes'
  },
  {
    icon: Coffee,
    title: 'Members Lounge',
    description: 'Exclusive space for relaxation and networking'
  }
];