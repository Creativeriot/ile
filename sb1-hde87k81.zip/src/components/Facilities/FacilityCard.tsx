import React from 'react';
import { motion } from 'framer-motion';
import { FacilityProps } from './types';

export default function FacilityCard({ facility, index }: FacilityProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true }}
      className="group rounded-xl bg-white p-8 shadow-sm transition-all hover:shadow-md"
    >
      <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-green-100 text-green-700 transition-all group-hover:bg-green-700 group-hover:text-white">
        <facility.icon className="h-6 w-6" />
      </div>
      <h3 className="mb-2 text-xl font-semibold text-gray-900">{facility.title}</h3>
      <p className="text-gray-600">{facility.description}</p>
    </motion.div>
  );
}