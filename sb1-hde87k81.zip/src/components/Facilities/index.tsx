import React from 'react';
import FacilityCard from './FacilityCard';
import { facilities } from './data';

export default function Facilities() {
  return (
    <section id="facilities" className="bg-gray-50 py-24">
      <div className="mx-auto max-w-7xl px-4">
        <div className="text-center">
          <h2 className="text-4xl font-bold text-gray-900">World-Class Facilities</h2>
          <p className="mt-4 text-xl text-gray-600">Experience luxury and excellence in every detail</p>
        </div>

        <div className="mt-20 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {facilities.map((facility, index) => (
            <FacilityCard
              key={index}
              facility={facility}
              index={index}
            />
          ))}
        </div>
      </div>
    </section>
  );
}