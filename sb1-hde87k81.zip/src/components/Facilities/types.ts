import { LucideIcon } from 'lucide-react';

export interface Facility {
  icon: LucideIcon;
  title: string;
  description: string;
}

export interface FacilityProps {
  facility: Facility;
  index: number;
}