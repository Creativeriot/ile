export const photos = [
  {
    url: 'https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa',
    description: 'Golf course at sunrise'
  },
  {
    url: 'https://images.unsplash.com/photo-1600740288397-63d11217f55b',
    description: 'Professional golfer teeing off'
  },
  {
    url: 'https://images.unsplash.com/photo-1592919505780-303950717480',
    description: 'Clubhouse exterior'
  },
  {
    url: 'https://images.unsplash.com/photo-1535131749006-b7f58c99034b',
    description: 'Golf cart on course'
  },
  {
    url: 'https://images.unsplash.com/photo-1611374243147-44a702c2d44c',
    description: 'Practice putting green'
  },
  {
    url: 'https://images.unsplash.com/photo-1622185135505-2d795003994a',
    description: 'Aerial view of golf course'
  }
];