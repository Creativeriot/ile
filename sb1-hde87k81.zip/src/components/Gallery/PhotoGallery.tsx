import React from 'react';
import Masonry from 'react-masonry-css';
import { motion } from 'framer-motion';
import { photos } from './data';

export default function PhotoGallery() {
  const breakpointColumns = {
    default: 4,
    1100: 3,
    700: 2,
    500: 1
  };

  return (
    <section id="gallery" className="bg-white py-24">
      <div className="mx-auto max-w-7xl px-4">
        <div className="text-center">
          <h2 className="text-4xl font-bold text-gray-900">Photo Gallery</h2>
          <p className="mt-4 text-xl text-gray-600">Capturing moments of excellence</p>
        </div>

        <Masonry
          breakpointCols={breakpointColumns}
          className="my-masonry-grid mt-16"
          columnClassName="my-masonry-grid_column"
        >
          {photos.map((photo, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="mb-4 overflow-hidden rounded-lg"
            >
              <motion.img
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.3 }}
                src={photo.url}
                alt={photo.description}
                className="h-full w-full object-cover"
              />
            </motion.div>
          ))}
        </Masonry>
      </div>
    </section>
  );
}