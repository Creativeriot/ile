import { LucideIcon } from 'lucide-react';

export interface Slide {
  image: string;
  title: string;
  subtitle: string;
}

export interface HeroSlideProps {
  slide: Slide;
  isActive: boolean;
}