export const slides = [
  {
    image: 'https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa?auto=format&fit=crop&w=2000&q=80',
    title: 'Welcome to Elite Golf Club',
    subtitle: 'Experience Golf at its Finest',
  },
  {
    image: 'https://images.unsplash.com/photo-1600740288397-63d11217f55b?auto=format&fit=crop&w=2000&q=80',
    title: 'World-Class Facilities',
    subtitle: 'Championship Courses & Premium Amenities',
  },
  {
    image: 'https://images.unsplash.com/photo-1592919505780-303950717480?auto=format&fit=crop&w=2000&q=80',
    title: 'Join Our Community',
    subtitle: 'Exclusive Member Benefits & Events',
  },
];