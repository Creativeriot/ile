import React from 'react';
import { motion } from 'framer-motion';
import { HeroSlideProps } from './types';

export default function HeroSlide({ slide, isActive }: HeroSlideProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{
        opacity: isActive ? 1 : 0,
        scale: isActive ? 1 : 1.1,
      }}
      transition={{ duration: 0.7 }}
      className="absolute inset-0"
      style={{
        display: isActive ? 'block' : 'none',
      }}
    >
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${slide.image})` }}
      >
        <div className="absolute inset-0 bg-black/40" />
      </div>
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center text-white">
          <motion.h1
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="mb-4 text-6xl font-bold"
          >
            {slide.title}
          </motion.h1>
          <motion.p
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="mb-8 text-xl"
          >
            {slide.subtitle}
          </motion.p>
          <motion.button
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="rounded-full bg-white px-8 py-3 text-lg font-semibold text-green-800 transition hover:bg-green-100"
          >
            Book a Tee Time
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
}