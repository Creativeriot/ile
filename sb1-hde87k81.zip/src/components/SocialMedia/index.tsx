import React from 'react';
import { motion } from 'framer-motion';
import { Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

const socialLinks = [
  {
    name: 'Facebook',
    url: 'https://facebook.com/elitegolfclub',
    icon: Facebook,
    color: 'hover:text-blue-600',
  },
  {
    name: 'Twitter',
    url: 'https://twitter.com/elitegolfclub',
    icon: Twitter,
    color: 'hover:text-blue-400',
  },
  {
    name: 'Instagram',
    url: 'https://instagram.com/elitegolfclub',
    icon: Instagram,
    color: 'hover:text-pink-600',
  },
  {
    name: 'YouTube',
    url: 'https://youtube.com/elitegolfclub',
    icon: Youtube,
    color: 'hover:text-red-600',
  },
];

export default function SocialMedia() {
  return (
    <section className="bg-white py-16">
      <div className="mx-auto max-w-7xl px-4">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900">Connect With Us</h2>
          <p className="mt-4 text-xl text-gray-600">Follow us on social media</p>
        </div>

        <div className="mt-8 flex justify-center space-x-8">
          {socialLinks.map((social, index) => (
            <motion.a
              key={social.name}
              href={social.url}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className={`text-gray-400 transition ${social.color}`}
            >
              <social.icon className="h-8 w-8" />
              <span className="sr-only">{social.name}</span>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}