import React from 'react';
import { HelmetProvider } from 'react-helmet-async';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import Facilities from './components/Facilities';
import PhotoGallery from './components/Gallery/PhotoGallery';
import Blog from './components/Blog';
import Events from './components/Events';
import Newsletter from './components/Newsletter';
import Contact from './components/Contact';
import SocialMedia from './components/SocialMedia';
import SEO from './components/SEO';
import LoginModal from './components/auth/LoginModal';

function App() {
  const [isLoginModalOpen, setIsLoginModalOpen] = React.useState(false);

  return (
    <HelmetProvider>
      <div className="min-h-screen">
        <SEO />
        <Navigation onLoginClick={() => setIsLoginModalOpen(true)} />
        <Hero />
        <Facilities />
        <PhotoGallery />
        <Blog />
        <Events />
        <Newsletter />
        <Contact />
        <SocialMedia />
        <LoginModal
          isOpen={isLoginModalOpen}
          onClose={() => setIsLoginModalOpen(false)}
        />
      </div>
    </HelmetProvider>
  );
}

export default App;